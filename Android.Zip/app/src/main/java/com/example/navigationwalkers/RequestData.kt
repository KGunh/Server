package com.example.navigationwalkers

data class RequestData(
    val from: LocationData,
    val to: LocationData
)
