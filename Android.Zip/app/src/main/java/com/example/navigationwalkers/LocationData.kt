package com.example.navigationwalkers

data class LocationData(
    val lon: Double,
    val lat: Double
)
